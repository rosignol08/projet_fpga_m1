# Usage with Vitis IDE:
# In Vitis IDE create a Single Application Debug launch configuration,
# change the debug type to 'Attach to running target' and provide this 
# tcl script in 'Execute Script' option.
# Path of this script: D:\telechargements\app_dcc_system\_ide\scripts\systemdebugger_app_dcc_system_standalone.tcl
# 
# 
# Usage with xsct:
# To debug using xsct, launch xsct and run below command
# source D:\telechargements\app_dcc_system\_ide\scripts\systemdebugger_app_dcc_system_standalone.tcl
# 
connect -url tcp:127.0.0.1:3121
targets -set -filter {jtag_cable_name =~ "Digilent Basys3 210183BCBB5FA" && level==0 && jtag_device_ctx=="jsn-Basys3-210183BCBB5FA-0362d093-0"}
fpga -file D:/telechargements/app_dcc/_ide/bitstream/system_dcc_final.bit
targets -set -nocase -filter {name =~ "*microblaze*#0" && bscan=="USER2" }
loadhw -hw D:/telechargements/train_projet/export/train_projet/hw/system_dcc_final.xsa -regs
configparams mdm-detect-bscan-mask 2
targets -set -nocase -filter {name =~ "*microblaze*#0" && bscan=="USER2" }
rst -system
after 3000
targets -set -nocase -filter {name =~ "*microblaze*#0" && bscan=="USER2" }
dow D:/telechargements/app_dcc/Debug/app_dcc.elf
targets -set -nocase -filter {name =~ "*microblaze*#0" && bscan=="USER2" }
con
