# 
# Usage: To re-create this platform project launch xsct with below options.
# xsct D:\telechargements\train_projet\platform.tcl
# 
# OR launch xsct and run below command.
# source D:\telechargements\train_projet\platform.tcl
# 
# To create the platform in a different location, modify the -out option of "platform create" command.
# -out option specifies the output directory of the platform project.

platform create -name {train_projet}\
-hw {D:\fpga\project_2\system_dcc_wrapper.xsa}\
-proc {microblaze_0} -os {standalone} -fsbl-target {psu_cortexa53_0} -out {D:/telechargements}

platform write
platform generate -domains 
platform active {train_projet}
platform generate
platform clean
platform generate
platform active {train_projet}
platform config -updatehw {D:/fpga/project_2/system_dcc_final.xsa}
platform generate -domains 
platform config -updatehw {D:/fpga/project_2/system_dcc_final.xsa}
platform config -updatehw {D:/fpga/project_2/system_dcc_final.xsa}
platform config -updatehw {D:/fpga/project_2/system_dcc_final.xsa}
platform clean
platform clean
platform config -updatehw {D:/fpga/project_2/system_dcc_final.xsa}
platform clean
platform clean
platform clean
platform clean
platform generate
platform clean
platform generate
