library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity CENTRALE_DCC_tb is
end CENTRALE_DCC_tb;

architecture Behavioral of CENTRALE_DCC_tb is
    signal Reset      : std_logic := '1';
    signal Clk_In     : std_logic := '0';
    signal TRAME_DCC  : std_logic_vector(50 downto 0) := (others => '0');
    signal SORTIE_DCC : std_logic;
    
    constant T_100MHz : time := 10 ns;  -- P??riode pour 100 MHz
begin

    -- Instanciation du module CENTRALE_DCC
    UUT: entity work.CENTRALE_DCC
    port map(Reset, Clk_In, TRAME_DCC, SORTIE_DCC);
    
    -- G??n??ration de l'horloge syst??me (100 MHz) 
    process 
    begin 
        Clk_In <= not Clk_In;
        wait for T_100MHz / 2;
    end process;
    
    process 
    begin 
        -- ==============================================================
        -- PHASE 1 : Initialisation et Reset
        -- ==============================================================
        
        -- (223 bits ?? '1') & '0' & x"03" & '0' & x"3F" & '0' & "3C" & '1'
        -- 23 bits + 1 + 8 + 1 + 8 + 1 + 8 + 1 = 24 + 24 + 3 = 51 bits
        TRAME_DCC <= "11111111111111111111111" & '0' & "00000011" & '0' & "00111111" & '0' & "00111100" & '1';
        
        wait for 1 us;
        
        -- On l??ve le RESET pour d??dmarrer la machine
        RESET <= '0';
        
        -- ==============================================================
        -- PHASE 2 : Observation (Attente passive)
        -- ==============================================================
        -- protocol : 
        -- Attendre 6 ms (Tempo)
        -- Charger la trame dans le registre
        -- Envoyer les 51 bits un par un via DCC_Bit_0 / DCC_Bit_1
        -- Recommencer 
        
        -- On laisse tourner la simulation pendant 30 millisecondes 
        -- pour avoir le temps de voir l'envoi complet d'au moins 2 trames.
        wait for 30 ms; 
        
        report "SIMULATION DE LA CENTRALE TERMINEE." severity note;
        wait; -- Arr??t d??finitif de la simulation
    end process;
        
        
end Behavioral;
