/*
 * main.c
 *
 *  Created on: Mar 23, 2026
 *      Author: ji
 */




/***************************** Include Files *******************************/
#include "my_led.h"
#include "xil_io.h"
#include "xparameters.h"
#include "xgpio.h"

/************************** Function Definitions ***************************/

int main(){
	XGpio sw_gpio;
	u32 sw_state;
	u32 reg0_data, reg1_data;

	XGpio_Initialize(&sw_gpio, XPAR_SW_DEVICE_ID);
	XGpio_SetDataDirection(&sw_gpio,1,0xF);

	while(1){
		sw_state = XGpio_DiscreteRead(&sw_gpio, 1);

		reg0_data =0;
		reg1_data =0;

		// On isole le bit 0 et le bit 1 des interrupteurs pour slv_reg0
		reg0_data |= sw_state & 0x03;

		// On isole le bit 2 et le bit 3 des interrupteurs et on decale pour slv_reg1
		reg1_data |= (sw_state >> 2) & 0x03;

		MY_LED_mWriteReg(XPAR_MY_LED_0_S00_AXI_BASEADDR, MY_LED_S00_AXI_SLV_REG0_OFFSET, reg0_data);
		MY_LED_mWriteReg(XPAR_MY_LED_0_S00_AXI_BASEADDR, MY_LED_S00_AXI_SLV_REG1_OFFSET, reg1_data);
	}
	return 0;
}
