library ieee;
use ieee.std_logic_1164.all;

entity Led is
port(	
		sw_state: in std_logic_vector(3 downto 0);
		leds : out std_logic_vector(15 to 0)
	);
end Led;

architecture Archi of Led is
begin
        leds(0) <= sw_state(0);
        leds(1) <= sw_state(0);
        leds(2) <= sw_state(0);
        leds(3) <= sw_state(0);
        
        leds(4) <= sw_state(1);
        leds(5) <= sw_state(1);
        leds(6) <= sw_state(1);
        leds(7) <= sw_state(1);
        leds(8) <= sw_state(2);
        leds(9) <= sw_state(2);
        leds(10) <= sw_state(2);
        leds(11) <= sw_state(2);
        leds(12) <= sw_state(3);
        leds(13) <= sw_state(3);
        leds(14) <= sw_state(3);
        leds(15) <= sw_state(3);
end Archi;