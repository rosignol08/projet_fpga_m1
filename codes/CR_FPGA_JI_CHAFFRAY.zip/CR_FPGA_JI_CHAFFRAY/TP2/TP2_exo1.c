#include "xgpio.h"
#include "xparameters.h"
#include "sleep.h"
#include "stdio.h"
#define XPAR_LED_SWITCH_DEVICE_ID 1
#define XPAR_BOUTONS_DEVICE_ID 0

int main() {
    XGpio led0, button;
    XGpio_Initialize(&led0, XPAR_LED_SWITCH_DEVICE_ID);
    XGpio_Initialize(&button, XPAR_BOUTONS_DEVICE_ID);

    XGpio_SetDataDirection(&led0,1,0xF);//tous les switchs en input
	XGpio_SetDataDirection(&led0,2,0); // tous les leds en output
    XGpio_SetDataDirection(&button,1,0xF);

    int val = 0;
	int btn_state = 0;
	int led_actuelles = 0;
	int cpt = 0;
	int rebond = 0;
	int blink_timer = 0;

	while(1) {
		// 1. Lecture de tous les capteurs au début du cycle
		val = XGpio_DiscreteRead(&led0, 1);
		btn_state = XGpio_DiscreteRead(&button, 1);

		// 2. Gestion propre de l'anti-rebond
		if (rebond > 0) {
			rebond--;
		}

		int sortie_led = 0; // Valeur qu'on va envoyer aux LEDs à la fin

		// 3. Logique de l'interrupteur 1 (Compteur et boutons)
		if (val == 2 || val == 3) { // Si le switch 1 est relevé (bit 1 à '1')
			if (rebond == 0) {
				if (btn_state & 2) { // Bouton Center
					cpt = (cpt + 1) % 16;
					rebond = 20; // 20 cycles * 10ms = 200 ms d'anti-rebond (parfait pour un humain)
				}
				if (btn_state & 1) { // Bouton Right
					led_actuelles &= 0xFF0F; // Eteint les LEDs 7 à 4
					rebond = 20;
				}
				if (btn_state & 4) { // Bouton Left
					led_actuelles |= 0x00F0; // Allume les LEDs 7 à 4
					rebond = 20;
				}
			}
		}

		// 4. Logique de l'interrupteur 0 (Clignotement indépendant)
		if ((val & 1) == 1) { // Si le switch 0 est relevé (bit 0 à '1')
			blink_timer++;
			if (blink_timer % 100 < 50) { // Crée un clignotement visible (500ms ON, 500ms OFF)
				sortie_led |= 0xFF00; // Allume les 8 LEDs de gauche
			}
		}

		// 5. On écrit l'état final sur les LEDs une seule fois par cycle
		sortie_led |= (cpt + led_actuelles ); // Ajoute le résultat aux LEDs

		XGpio_DiscreteWrite(&led0, 2, sortie_led);

		usleep(100000);
	}
	return 0;
}
