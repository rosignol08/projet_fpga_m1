----------------------------------------------------------------------------------
-- Company: UPMC
-- Engineer: Julien Denoulet
-- 
-- Create Date:   	Septembre 2016 
-- Module Name:    	Impulse_Count - Behavioral 
-- Project Name: 		TP1 - FPGA1
-- Target Devices: 	Nexys4 / Artix7

-- XDC File:			Impulse_Count.xdc					

-- Description: Compteur d'Impulsions - Version KO
--
--		Compteur d'Impulsions sur 4 bits
--			- Le Compteur s'Incr�mente si on Appuie sur le Bouton Left
--			- Le Compteur se'D�cr�mente si on Appuie sur le Bouton Center
--			- Sup Passe � 1 si le Compteur D�passe 9
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;

entity IMPULSE_COUNT is
	Port ( Clk : in  STD_LOGIC;								-- Horloge
		   Reset : in  STD_LOGIC;								-- Reset Asynchrone
           Button_L : in  STD_LOGIC;							-- Bouton Left
           Button_C : in  STD_LOGIC;							-- Bouton Center
           Count : out  STD_LOGIC_VECTOR (3 downto 0);	-- Compteur d'Impulsions
           Sup : out  STD_LOGIC);								-- Indicateur Valeur Seuil
end IMPULSE_COUNT;

architecture Behavioral of IMPULSE_COUNT is

signal cpt: std_logic_vector(3 downto 0);		-- Compteur d'Impulsions
signal btn_l_prev: std_logic;							-- Memoire etat bouton left
signal btn_c_prev: std_logic;							-- Memoire etat bouton center
signal cooling_btn_gauche: integer range 0 to 1000000;	-- Anti-rebond bouton left
signal cooling_btn_centre: integer range 0 to 1000000;	-- Anti-rebond bouton center

begin

	count <= cpt;	-- Affichage en Sortie du Compteur

	-------------------------
	-- Gestion du Compteur --
	-------------------------
	process(reset,Clk)
		variable cpt_next: std_logic_vector(3 downto 0);

	begin

		-- Reset Asynchrone
		if reset='1' then cpt<="0000"; end if;

		elsif rising_edge(Clk) then
			cpt_next := cpt;

			if cooling_btn_gauche > 0 then
				cooling_btn_gauche <= cooling_btn_gauche - 1;
			end if;

			if cooling_btn_centre > 0 then
				cooling_btn_centre <= cooling_btn_centre - 1;
			end if;

			-- on attend si le delay anti-rebond est pas encore expire
			if (Button_L = '1') and (btn_l_prev = '0') and (cooling_btn_gauche = 0) then
				cpt_next := cpt_next + 1;
				cooling_btn_gauche <= 1000000;
			end if;

			-- pareil on attend si le delay anti-rebond est pas encore expire pour l'autre bouton
			if (Button_C = '1') and (btn_c_prev = '0') and (cooling_btn_centre = 0) then
				cpt_next := cpt_next - 1;
				cooling_btn_centre <= 1000000;
			end if;

			cpt <= cpt_next;
			btn_l_prev <= Button_L;
			btn_c_prev <= Button_C;
		end if;
		
	end process;

	-------------------------
	-- Gestion du Flag Sup --
	-------------------------
	process(Cpt)

	begin
		
		-- Mise � 1 si CPT D�passe 9. A 0 Sinon...
		if (cpt > 9) then 			
			Sup<='1'; 									
		else 							
			Sup<='0'; 
		end if;
	end process;

end Behavioral;

